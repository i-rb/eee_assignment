pcom <-
function(W, r){ 
  N=dim(W)[2]
  ff= (W%*%t(W))/N
  mat = eigen(ff)$vectors
  if (r!=1){return(mat[,1:r])}
  if (r==1){return(matrix(mat[,1:r]))}
}
