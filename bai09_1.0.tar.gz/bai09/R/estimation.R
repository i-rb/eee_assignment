estimation <-
function(listX, listY, init_lamb, init_fac, N, r){
  xinv = inv_xtx(listX)
  fac_i = init_fac
  lamb_i = init_lamb
  for (i in 1:N){
    bi = betahat(FactorMat = fac_i, listLamb = lamb_i, listX = listX, listY = listY, xinv)
    W = residuals(bi, listX, listY)
    fac_i = pcom(W, r)
    tftinv = solve(t(fac_i)%*%fac_i)%*%t(fac_i)
    lamb_i = newlamb(tftinv, W)
  }
  return(list(betahat = bi, W = W, fac = fac_i, lamb = lamb_i))
}
