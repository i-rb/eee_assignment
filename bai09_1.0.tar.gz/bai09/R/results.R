results <-
function(object){
  cat("Estimation of beta:\n\n")
  res = object$betahat
  colnames(res)=object$yName
  rownames(res)=object$xNames
  print(res)
}
