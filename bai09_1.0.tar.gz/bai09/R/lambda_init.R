lambda_init <-
function(N, r=2){
  indFact = list()
  for (i in 1:N){
    indFact[[i]] = matrix(rnorm(2), nrow = r, ncol = 1)
  }
  return(indFact)
}
