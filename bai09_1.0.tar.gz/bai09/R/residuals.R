residuals <-
function(betahat, listX, listY){
  interlist = lapply(listX, "%*%",betahat)
  W= mapply("-", listY, interlist, SIMPLIFY = TRUE)
  return(W)
}
