bai09 <-
function(formula, data, index, Niter, r, loading_init, factor_init){
  if (missing(formula)){
    stop("Missing formula")
  }
  if (missing(data)){
    stop("Missing data")
  }
  if (missing(index)){
    stop("Missing indeces")
  }
  
  if (missing(Niter)){
    Niter = 100
  }
  
  if (missing(r)){
    r=2
  }
  ids = unique(data[index[1]][,1])
  N = length(ids)
  times = unique(data[index[2]][,1])
  time = length(times)
  YLIST = list()
  XLIST = list()
  
  
  form = formula
  l_form = length(all.vars(form)) # data[,all.vars(rr)[[1]]]
  for (i in 1:N){
    YLIST[[i]] = matrix(data[data[index[[1]]] == ids[i],][,all.vars(form)[[1]]]) # matrix(data[data[index[[1]]] == ids[i],][,toString(form[[2]])])
    matx = matrix(0, nrow=time, ncol=l_form-1)
    for (var in (2:l_form)){
      matx[,var-1] = matrix(data[data[index[[1]]] == ids[i],][,all.vars(form)[[var]]]) # matrix(data[data[index[[1]]] == ids[i],][,toString(form[[3]][[var]])])
    }
    XLIST[[i]] = matx
  }
  
  if (missing(loading_init)){
    loading_init = lambda_init(N, r)
  }
  
  if (missing(factor_init)){
    factor_init = matrix(rnorm(time*r), time, r)
  }
  dats = list(X=XLIST, Y=YLIST, load=loading_init, fac=factor_init)
  v = all.vars(form)
  xNames = list(v[2:length(v)])
  yName  = v[1]
  ret_list = estimation(listX=dats$X, listY=dats$Y, init_lamb=dats$load, init_fac=dats$fac, N=Niter, r=r)
  ret_list = c(ret_list, xNames = xNames, yName = yName)
  return(ret_list)
}
