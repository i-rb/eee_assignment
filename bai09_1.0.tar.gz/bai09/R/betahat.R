betahat <-
function(FactorMat, listLamb, listX,listY, xxinv){
  if (missing(xxinv)){
    xxinv = inv_xtx(listX)}
  list_inter = list()
  for (i in 1:length(listX)){
    list_inter[[i]] = t(listX[[i]]) %*% (listY[[i]] - FactorMat %*% listLamb[[i]])
  }
  partial = Reduce('+', list_inter)
  return(xxinv%*%partial)
}
