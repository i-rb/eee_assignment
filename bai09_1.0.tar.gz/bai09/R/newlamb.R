newlamb <-
function(tftin, W){
  W = lapply(seq_len(ncol(W)), function(i) matrix(W[,i]))
  nlambs = lapply(W,FUN= function(x) tftin%*%x)
  return(nlambs)
}
