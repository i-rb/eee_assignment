inv_xtx <-
function(listX){
  N = length(listX)
  dims = dim(listX[[1]]) 
  mat = matrix(0,dims[2],dims[2])
  for (i in listX){
    mat = mat + t(i)%*%i
  }
  mat = solve(mat)
  return(mat)
}
